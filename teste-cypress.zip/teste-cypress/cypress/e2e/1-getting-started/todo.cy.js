/// <reference types="cypress" />


/* describe('Teste de Logon no Itaú', () => {
  it('Deve logar com sucesso', () => {
    // Visita a página de login
    cy.visit('https://www.itau.com.br');

    // Espera que o botão de login esteja visível
    cy.get('.login-button').should('be.visible').click(); // Adapte o seletor conforme necessário

    // Preenche os campos de login
    cy.get('input[name="usuario"]').type('usuario_teste'); // Substitua com o usuário real
    cy.get('input[name="senha"]').type('senha_teste'); // Substitua com a senha real

    // Submete o formulário de login
    cy.get('button[type="submit"]').click();

    // Valida se o login foi bem-sucedido verificando a presença de um elemento específico na página inicial
    cy.url().should('include', '/home'); // URL após login bem-sucedido
    cy.get('.nome-usuario').should('contain', 'usuario_teste'); // Confirma se o nome do usuário aparece
  });
});
*/


describe('Teste de Transação via Pix no Itaú', () => {
  it('Deve realizar uma transação via Pix com sucesso', () => {
    // Visita a página de login
    cy.visit('https://www.itau.com.br');

    // Loga no sistema (presumimos que o login já tenha sido feito no teste anterior)
    cy.get('input[name="usuario"]').type('usuario_teste');
    cy.get('input[name="senha"]').type('senha_teste');
    cy.get('button[type="submit"]').click();

    // Espera que a página de transferências esteja carregada
    cy.get('.transferencias-button').click();

    // Seleciona a opção de transferência via Pix
    cy.get('.pix-option').click(); // Seletor para a opção Pix, ajuste conforme necessário

    // Preenche os dados da transferência
    cy.get('input[name="chave_pix"]').type('chave_pix_destinatario');
    cy.get('input[name="valor"]').type('100'); // Valor da transferência

    // Confirma a transação
    cy.get('button[type="submit"]').click();

    // Valida se a transação foi realizada com sucesso
    cy.get('.transacao-confirmada').should('contain', 'Transferência realizada com sucesso');
    cy.get('.saldo-atual').should('contain', '100'); // Confirmar que o saldo foi atualizado
  });
});





