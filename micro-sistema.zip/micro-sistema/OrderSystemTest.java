import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class OrderSystemTest {

    private OrderSystem orderSystem;

    @BeforeEach
    public void setUp() {
        orderSystem = new OrderSystem();
    }

    @Test
    public void testExceedMaxTransactionValue() {
        // Teste de transação que excede o limite máximo de transação (R$ 1.000.000).
        // Neste caso, a transação não pode ser realizada, pois excede o limite.
        assertDoesNotThrow(() -> {
            orderSystem.placeOrder("account1", "fund1", 1_500_000.00);  // Tentando uma transação de R$ 1.500.000
        });
    }

    @Test
    public void testInsufficientAccountBalance() {
        // Teste de saldo insuficiente na conta para realizar a transação.
        // A conta "account1" tem R$ 500.000,00, mas tentamos realizar uma transação de R$ 600.000,00, o que deve falhar.
        assertDoesNotThrow(() -> {
            orderSystem.placeOrder("account1", "fund1", 600_000.00);  // Tentando uma transação maior que o saldo da conta
        });
    }

    @Test
    public void testInsufficientFundBalance() {
        // Teste de saldo insuficiente no fundo para realizar a transação.
        // O fundo "fund2" tem R$ 500.000,00, mas estamos tentando realizar uma transação de R$ 6000.000,00, o que deve falhar.
        assertDoesNotThrow(() -> {
            orderSystem.placeOrder("account2", "fund2", 600_000.00);  // Tentando uma transação maior que o saldo do fundo
        });
    }

    @Test
    public void testAccountWithoutFundLinkage() {
        // Teste onde a conta "account1" não possui vínculo com o fundo "fund2".
        // O sistema deve gerar um erro dizendo que a conta não tem cotas associadas ao fundo.
        assertDoesNotThrow(() -> {
            orderSystem.placeOrder("account1", "fund2", 9000.00);  // Tentando realizar uma transação em um fundo não vinculado à conta
        });
    }


    @Test
    public void testTransactionWorksWhenAccountHasExactShares() {
        // Teste onde a conta tem exatamente o número de cotas necessárias para a transação.
        // A conta "account2" tem 50 cotas, cada uma no valor de R$ 100, e estamos tentando vender R$ 5.000,00 (50 cotas).
        assertDoesNotThrow(() -> {
            orderSystem.placeOrder("account2", "fund2", 5_000.00);  // Conta com o número exato de cotas para a transação
        });
    }
}
