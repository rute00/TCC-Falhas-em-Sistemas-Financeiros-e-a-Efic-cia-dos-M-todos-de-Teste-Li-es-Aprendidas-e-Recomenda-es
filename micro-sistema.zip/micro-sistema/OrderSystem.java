import java.util.HashMap;
import java.util.Map;

public class OrderSystem {

    private static double MAX_TRANSACTION_VALUE = 1_000_000.00;
    private static double DAILY_TRANSACTION_LIMIT = 10_000_000.00;
    private static final double COTA_VALUE = 100.00;  // Valor fixo de cada cota (R$ 100)
    private double dailyTransactionTotal = 0;

    private Map<String, Double> accounts = new HashMap<>();
    private Map<String, Double> accountFundShares = new HashMap<>();
    private Map<String, Double> funds = new HashMap<>(); // Saldo dos fundos de investimento

    public OrderSystem() {
        // Configuracoes iniciais de contas e fundos
        accounts.put("account1", 500_000.00);
        accounts.put("account2", 2_000_000.00);
        
        // Fundos de investimento (saldo de cada fundo)
        funds.put("fund1", 5_000_000.00);  // Fundo 1 com saldo de 5 milhoes
        funds.put("fund2", 500_000.00);  // Fundo 2 com saldo de 1 milhao
        
        // Quantidade de cotas associadas às contas
        accountFundShares.put("account1_fund1", 300.0);
        accountFundShares.put("account2_fund2", 50.0);
    }

    public synchronized boolean placeOrder(String accountId, String fundId, double orderValue) throws Exception {
        // Verificacao do limite de valor da transacao
        if (orderValue > MAX_TRANSACTION_VALUE) {
            throw new Exception("Erro: Transacao excede o limite de valor permitido.");
        }

        // Verificacao do limite diario total
        if (dailyTransactionTotal + orderValue > DAILY_TRANSACTION_LIMIT) {
            throw new Exception("Erro: limite diario de transacoes excedido.");
        }

        // Verificacao de saldo da conta
        if (!accounts.containsKey(accountId) || accounts.get(accountId) < orderValue) {
            throw new Exception("Erro: Saldo insuficiente na conta.");
        }

        // Verificacao de saldo do fundo de investimento
        if (!funds.containsKey(fundId) || funds.get(fundId) < orderValue) {
            throw new Exception("Erro: Fundo de investimento nao possui saldo suficiente.");
        }

        // Verificacao se a conta possui vinculo com o fundo
        if (!accountFundShares.containsKey(accountId + "_" + fundId)) {
            throw new Exception("Erro: A conta nao possui cotas no fundo especificado.");
        }

        // Verificar se a conta tem cotas suficientes no fundo
        double accountShares = accountFundShares.get(accountId + "_" + fundId);
        double requiredShares = orderValue / COTA_VALUE;  // Quantidade de cotas necessarias para a transacao

        if (accountShares < requiredShares) {
            throw new Exception("Erro: Conta nao possui cotas suficientes no fundo.");
        }

        // Atualiza o saldo da conta, do fundo, e as cotas associadas
        accounts.put(accountId, accounts.get(accountId) - orderValue);
        funds.put(fundId, funds.get(fundId) - orderValue);

        // Atualiza as cotas da conta (diminuindo as cotas apos a transacao)
        accountFundShares.put(accountId + "_" + fundId, accountShares - requiredShares);

        // Incrementa o total diario de transacoes
        dailyTransactionTotal += orderValue;

        return true;
    }

    public double getAccountBalance(String accountId) {
        return accounts.getOrDefault(accountId, 0.0);
    }

    public double getFundBalance(String fundId) {
        return funds.getOrDefault(fundId, 0.0);
    }

    public double getDailyTransactionTotal() {
        return dailyTransactionTotal;
    }
}
