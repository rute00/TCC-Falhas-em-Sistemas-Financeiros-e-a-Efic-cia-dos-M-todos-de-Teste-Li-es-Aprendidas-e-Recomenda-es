import hashlib

def calcular_hash_arquivo(caminho_arquivo, algoritmo='sha256'):
    """
    Calcula o hash de um arquivo usando o algoritmo especificado.
    
    :param caminho_arquivo: Caminho do arquivo que será verificado
    :param algoritmo: Algoritmo de hashing ('md5', 'sha256', etc.)
    :return: Hash do arquivo em formato hexadecimal
    """
    hash_func = hashlib.new(algoritmo)
    
    with open(caminho_arquivo, 'rb') as arquivo:
        while chunk := arquivo.read(8192):  # Lê o arquivo em blocos de 8192 bytes
            hash_func.update(chunk)
    
    return hash_func.hexdigest()

def verificar_integridade(caminho_arquivo, hash_esperado, algoritmo='sha256'):
    """
    Verifica se o hash de um arquivo corresponde ao hash esperado.
    
    :param caminho_arquivo: Caminho do arquivo que será verificado
    :param hash_esperado: Hash conhecido e esperado do arquivo
    :param algoritmo: Algoritmo de hashing ('md5', 'sha256', etc.)
    :return: True se o hash corresponde, False se o arquivo está corrompido
    """
    hash_calculado = calcular_hash_arquivo(caminho_arquivo, algoritmo)
    print(f"Hash calculado: {hash_calculado}")
    print(f"Hash esperado: {hash_esperado}")
    
    return hash_calculado == hash_esperado

# Exemplo de uso
caminho_arquivo = 'C:\FontesSaudeAzure\Plano de Saude\Biometria\TotvsBio.PRW'
hash_esperado = 'a1b2c3d4e5f67890abcdef1234567890abcdef1234567890abcdef1234567890'  # Substitua pelo hash correto

if verificar_integridade(caminho_arquivo, hash_esperado):
    print("O arquivo está íntegro.")
else:
    print("O arquivo está corrompido.")
